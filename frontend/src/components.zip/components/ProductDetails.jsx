
import React, { useContext } from "react";
import { useParams } from "react-router-dom";
import { products } from "../data/mockData";
import { CartContext } from "../context/CartContext";
import "../styles/ProductDetails.css";

const ProductDetails = () => {
  const { productId } = useParams();
  const product = products.find((prod) => prod.id === parseInt(productId));
  const { addToCart, notification } = useContext(CartContext);

  if (!product) return <p>Product not found.</p>;

  return (
    <div className="product-details">
      <img src={product.image} alt={product.name} />
      <h1>{product.name}</h1>
      <p>{product.description}</p>
      <p>
        <strong>Price:</strong> Rs. {product.price}
      </p>
      <button onClick={() => addToCart(product)}>Add to Cart</button>
      {notification && (
        <div className="notification">
          <p>{notification}</p>
        </div>
      )}
    </div>
  );
};

export default ProductDetails;