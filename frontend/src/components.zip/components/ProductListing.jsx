import React, { useState, useContext, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { products } from "../data/mockData";
import { CartContext } from "../context/CartContext";
import "../styles/ProductListing.css";

const ProductListing = () => {
  const [filter, setFilter] = useState("");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const { addToCart, notification } = useContext(CartContext);

  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const category = params.get("category");
    if (category) {
      setFilter(category);
    }
  }, [location.search]);

  const handleCategoryChange = (e) => {
    const category = e.target.value;
    setFilter(category);

    navigate(`?category=${category}`, { replace: true });
  };

  const handleMinPriceChange = (e) => {
    const value = Math.max(0, Number(e.target.value)); // No negative
    setMinPrice(value || "");
  };

  const handleMaxPriceChange = (e) => {
    const value = Math.max(0, Number(e.target.value)); // No negative
    setMaxPrice(value || "");
  };

  const filteredProducts = products.filter((product) => {
    const matchesCategory = filter ? product.category === filter : true;
    const matchesPrice =
      (!minPrice || product.price >= minPrice) &&
      (!maxPrice || product.price <= maxPrice);
    return matchesCategory && matchesPrice;
  });

  return (
    <div className="product-listing">
      <h2>Product Listing</h2>
      <div className="filters">
        <label>
          Category:
          <select
            className="category"
            value={filter}
            onChange={handleCategoryChange}
          >
            <option value="">All</option>
            <option value="Women">Women</option>
            <option value="Men">Men</option>
            <option value="Kids">Kids</option>
          </select>
        </label>
        <label>
          Minimum Price:
          <input
            className="minprice"
            type="number"
            value={minPrice}
            onChange={handleMinPriceChange}
          />
        </label>
        <label>
          Maximum Price:
          <input
            className="maxprice"
            type="number"
            value={maxPrice}
            onChange={handleMaxPriceChange}
          />
        </label>
      </div>
      <div className="product-grid">
        {filteredProducts.map((product) => (
          <div key={product.id} className="product-card">
            <Link to={`/products/${product.id}`} className="product-card-link">
              <img src={product.image} alt={product.name} />
              <h3>{product.name}</h3>
              <p>Rs. {product.price}</p>
            </Link>
            <button onClick={() => addToCart(product)}>Add to Cart</button>
          </div>
        ))}
      </div>
      {notification && (
        <div className="notification">
          <p>{notification}</p>
        </div>
      )}
    </div>
  );
};

export default ProductListing;