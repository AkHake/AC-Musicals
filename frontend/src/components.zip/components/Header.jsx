import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { CartContext } from "../context/CartContext";
// import './Header.css';
import { FaCartShopping } from "react-icons/fa6";
import "../styles/Header.css";
import { GiMusicSpell } from "react-icons/gi";

const Header = () => {
  const { cart } = useContext(CartContext);

  return (
    <header className="header">
      <Link to="/" className="logo">
        AC Musicals <GiMusicSpell />
      </Link>
      <nav>
        {/* <Link to="/">Home</Link> */}
        <Link to="/products">Products</Link>
        <Link to="/register">Register</Link>
        <Link to="/login">Login</Link>
        <Link to="/cart">
          Cart <FaCartShopping /> ({cart.length})
        </Link>
        <Link to="/footer">About Us</Link>
      </nav>
    </header>
  );
};

export default Header;